# server.R - DESC
# server.R

# Copyright 2015 EC JRC
# Iago Mosqueira & Dimitrios Damalas. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC

shinyServer(function(input, output) {

# SUBSET
subsce <- reactive({

	# M
	if(!all(input$Minp == ""))
		idx <- sce[sce$M %in% input$Minp,]

	# sigmaR
	if(!all(input$sigmaRinp == ""))
		idx <- idx[idx$sigmaR %in% input$sigmaRinp,]
	
	# steepness
	if(!all(input$steepnessinp == ""))
		idx <- idx[idx$steepness %in% input$steepnessinp,]
	
	# cpuecv
	if(!all(input$cpuecvinp == ""))
		idx <- idx[idx$cpuecv %in% input$cpuecvinp,]
	
	# ess
	if(!all(input$essinp == ""))
		idx <- idx[idx$ess %in% input$essinp,]
	
	# llq
	if(!all(input$llqinp == ""))
		idx <- idx[idx$llq %in% input$llqinp,]
	
	# llsel
	if(!all(input$llselinp == ""))
		idx <- idx[idx$llsel %in% input$llselinp,]
	
	return(idx)
	}
)

# SUBSET om
subom <- reactive({

	return(om[,,,,,subsce()$number])
})

# SUBSET refpts
subrefpts <- reactive({
	
	return(refpts[,subsce()$number])
})


# plotTS
  output$plotTS <- renderPlot({

		plotTS(subom(), subrefpts())
      
	})

# plotTSC
  output$compareSce = renderText({
    
    input$compare_inp
    
  }) 

# plotA
  output$plotA <- renderPlot({
    
    plothistSSB(subom())
    
  }) 

# plotB
  output$plotB <- renderPlot({
    
    plotNSel(subom())
    
  }) 

# plotC
  output$plotC <- renderPlot({
    
    plotSR(subom())
    
  }) 


#
})
