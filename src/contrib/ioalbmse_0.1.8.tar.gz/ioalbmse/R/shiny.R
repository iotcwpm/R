# shiny.R - DESC
# shiny.R

# Copyright 2015 Iago Mosqueira. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:


# runapp
runapp <- function() {

	# LOAD data
	data(om)
	data(res)

	#
	appDir <- system.file("shiny-apps", "mseapp", package="ioalbmse")

	if(appDir =="") {
		stop("Could not find shiny app directory. Try re-installing the package")
	}

	shiny::runApp(appDir, display.mode="normal")
}
