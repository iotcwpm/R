
---
title: README.md
author: Iago Mosqueira, EC JRC G03
date: 12 October 2015
output:
  pdf_document:
    toc: true
    toc_depth: 2
    keep_md: true
rights:  Creative Commons Share Alike 4.0
---

# dygraph

<https://rstudio.github.io/dygraphs/>

# shinydashboard

<https://rstudio.github.io/shinydashboard/get_started.html>

# htmlwidgets

<http://www.htmlwidgets.org/>
