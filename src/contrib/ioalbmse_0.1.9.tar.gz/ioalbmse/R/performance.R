# performance.R - DESC
# /performance.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

# performance {{{

#' Compute performance indicators
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend
#' odio ac rutrum luctus. Aenean placerat porttitor commodo. Pellentesque eget porta
#' libero. Pellentesque molestie mi sed orci feugiat, non mollis enim tristique. 
#' Suspendisse eu sapien vitae arcu lobortis ultrices vitae ac velit. Curabitur id 
#' nunc euismod ante fringilla lobortis. Aliquam ullamcorper in diam non placerat. 
#'
#' Aliquam sagittis feugiat felis eget consequat. Praesent eleifend dolor massa, 
#' vitae faucibus justo lacinia a. Cras sed erat et magna pharetra bibendum quis in 
#' mi. Sed sodales mollis arcu, sit amet venenatis lorem fringilla vel. Vivamus vitae 
#' ipsum sem. Donec malesuada purus at libero bibendum accumsan. Donec ipsum sapien, 
#' feugiat blandit arcu in, dapibus dictum felis. 
#'
#' @param object Object holding the results of forward projections, \code{FLQuants}
#' @param refpts Reference points for calculations, \code{list}
#' @param indicators Indicators to be computed, as formnula, name and description, \code{list}
#'
#' @return data.frame Results of computing performance indicators 
#'
#' @name performance
#' @rdname performance
#' @aliases performance
#'
#' @author Iago Mosqueira, EC JRC
#' @seealso \code{\link{FLQuants}}
#' @keywords utilities
#' @examples
#'
performance <- function(object, refpts, indicators) {

	# EVAL along list
	res <- lapply(indicators,
		function(x) {
      as.data.frame(eval(x[names(x) == ""][[1]][[2]],
        c(object, as(refpts, 'list'))), drop=TRUE)
    })

  # ADD indicator column
  res <- Map(cbind, lapply(names(indicators), function(x) data.frame(indicator=x)), res)

  # JOIN
  res <- Reduce(rbind, res)

	return(res)
} # }}}
