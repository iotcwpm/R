# iterDrop.R - DESC
# iterDrop.R

# Copyright 2015 Iago Mosqueira. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:

# iterDrop {{{
iterDrop <- function(object) {

	foo <- function(x) {
  	if(sum(apply(x@.Data, 1:5, var, na.rm=TRUE), na.rm=TRUE) == 0)
    	x[,,,,,1]
    else
    x}

  return(qapply(object, foo))
} # }}}
