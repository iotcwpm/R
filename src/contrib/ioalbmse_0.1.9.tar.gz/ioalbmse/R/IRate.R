# IRate.R - Function implementing the IRate MP
# ioalbmse/R/IRate.R

# Copyright European Union, 2013-2016
# Authors: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#          Finlay Scott (EC JRC) <finlay.scott@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

# IRate - no error on estimate of CPUE and no error on TAC implementation {{{
IRate <- function(omp, sr, YEARS, responsiveness, hr_multiplier,
  biomass_threshold, biomass_limit, max_TAC, SLAG=2, MLAG=1, verbose=TRUE) {

  # Initial smoother value is 0
  cpue_smooth <- NULL

  for (i in YEARS) {

    # Get catch data, no error
    tc <- catch(omp)[,ac(i - SLAG)]

    # Get CPUE, perfect knowledge!
    cpue <- window(ssb(omp), end=i - SLAG) / 1000

        # Get smoothed CPUE using CPUE in last available timestep
        if (is.null(cpue_smooth)){
            cpue_smooth <- cpue[,ac(i - SLAG)]
        } else {
          cpue_smooth <- responsiveness * cpue[,ac(i - SLAG)] +
            (1 - responsiveness) * cpue_smooth
        }

        # Calc recommended catch scalar
        rate <- cpue_smooth
        rate[] <- (cpue_smooth - biomass_limit) * hr_multiplier /
          (biomass_threshold - biomass_limit)
        rate[cpue_smooth < biomass_limit] <- 0
        rate[cpue_smooth > biomass_threshold] <- hr_multiplier

        # set catch
        nc <- tc
        dimnames(nc) <- list(year=i + 1)
        nc[] <- pmin(c(cpue_smooth * rate), c(max_TAC))

        # Restrict change in catch?

        # Implementation error
        omp <- fwd(omp, as.fwdControl(catch=nc), sr=sr)

        # PRINT
        if(verbose) {
          cat("C_",i - 1, " = ", mean(tc), "  ",
            "CP_",i, " = ", mean(nc), "  ",
            "C_",i, " = ", mean(catch(omp)[,ac(i)]), "  ",
            "diffC",i, " = ", sum((c(nc) - c(catch(omp)[,ac(i)])) > 0.05), "  ",
            "SSB = ", mean(ssb(omp)[, ac(i)]), "  ",
            "\n", sep="")
        }
    }
  return(window(omp, end=i))
} # }}}
