# global.R - DESC
# global.R

# Copyright 2015 Iago Mosqueira. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:

# CREATE refpts FLPar from res
refpts <- FLPar(
	B0=res$TotBio_Unfished,
	SB0=res$SPB_1950,
	MSY=res$TotYield_MSY,
	SBMSY=res$SSB_MSY,
	FMSY=res$Fstd_MSY,
	SBtarget=res$SSB_MSY,
	Ftarget=res$Fstd_MSY)

dimnames(refpts)$iter <- as.character(res$number)

# CREATE scenarios df as.character
sce <- res[,1:8]
sce[] <- lapply(sce, as.character)

