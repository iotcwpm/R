# plots.R - DESC
# plots.R

# Copyright 2015 Iago Mosqueira. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:


# ploTS {{{
plotTS <- function(x, refpts) {

	dat <- FLQuants(`SSB (t)`=ssb(x) %/% refpts['SBMSY'],
									F=fbar(x) %/% refpts['FMSY'],
									Rec=rec(x))
	# refrpts lines
	line <- data.frame(qname=names(dat)[1:2], yintercept=c(1, 1))

	plot(dat) + geom_hline(data=line, aes(yintercept=yintercept), linetype=2, colour='black')
} # }}}

# plothistSSB {{{
plothistSSB <- function(x, year='2012') {

	dat <- ssb(x)[,as.character(year)]

	ggplot(dat, aes(x=data)) +
	geom_histogram(aes(y=..density..), fill='darkgrey', colour='black', binwidth=diff(range(dat)) / 20) +
	ylab("") + xlab("") +
  geom_density(alpha=.2, fill="#FF6666") +
	theme(axis.ticks.y=element_blank(), axis.text.y=element_blank(),
		plot.title = element_text(lineheight=.8, face="bold")) +
	ggtitle(expression(SSB[2012]))
} # }}}

# plotNSel {{{
plotNSel <- function(x, years=c(1950, 2012)) {

	dat <- as.data.frame(stock.n(x)[,as.character(years)], drop=TRUE) %>%
		group_by(year, age) %>%
		summarize(min = min(data), max = max(data), median = median(data))

	ggplot(as.data.frame(dat), aes(x=median, y=age, xmin=min, xmax=max)) +
		geom_errorbarh() +
		geom_point(aes(x=median)) +
		facet_grid(.~year) + 
		scale_y_reverse() +
		ylab("age") + xlab("") +
	theme(axis.ticks.x=element_blank(), axis.text.y=element_blank(),
		plot.title = element_text(lineheight=.8, face="bold")) +
	ggtitle("N at age")
} # }}}

# plotSR {{{
plotSR <- function(x) {

	dat <- model.frame(FLQuants(Rec=rec(x), SSB=ssb(x)), drop=TRUE)

	ggplot(dat, aes(x=SSB, y=Rec)) + geom_point(alpha=0.05) +
		ggtitle("Stock-recruit") + xlab("SSB (t)") + ylab("Recruits")
} # }}}
