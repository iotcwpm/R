#' @importFrom purrr map map_if walk2 keep map_at splice invoke some
#'   walk partial set_names %||%
NULL

#' Base ggproto classes for ggstance
#'
#' @seealso ggplot2::ggproto
#' @keywords internal
#' @name ggstance-ggproto
NULL
