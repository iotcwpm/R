/* $Id: ErrorHandler.h 1369 2009-05-31 01:31:48Z bradbell $ */
# include "cppad/error_handler.hpp"
