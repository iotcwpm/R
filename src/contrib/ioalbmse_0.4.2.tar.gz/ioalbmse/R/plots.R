# plots.R - DESC
# ioalbmse/R/plots.R

# Copyright European Union, 2015-2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

globalVariables("indicators")

# labr {{{
labr <- function(variable, value) {
  return(paste(value, lapply(indicators, "[[", "name")[value]))
} # }}}

# plotTO {{{

#' plotTO(perq, "S1", "T1", "2028") + xlim(c(0, 0.30)) + ylim(c(0.5, 1.5))
plotTO <- function(data, x, y, year=max(data$year)) {

  # HACK: scoping issue in data.table due to match arg & col names
  ye <- year
  
  dat <- data[indicator %in% c(x, y)][year %in% ye]
  names <- dat[indicator %in% c(x, y), name][1:2]

  dat <- dcast(dat, year ~ indicator, sep="",
    value.var=c('10%','25%','50%','75%','90%'))

  p <- ggplot(dat, aes_q(x=as.name(paste0("50%", x)),
      y=as.name(paste0("50%", y)))) +
    # vertical lines
    geom_linerange(aes_q(ymin=as.name(paste0("10%", y)),
      ymax=as.name(paste0("90%", y)))) +
    geom_linerange(aes_q(ymin=as.name(paste0("25%", y)),
      ymax=as.name(paste0("75%", y))), size=1) +
    # horizontal lines
    geom_linerangeh(aes_q(xmin=as.name(paste0("10%", x)),
      xmax=as.name(paste0("90%", x)))) +
    geom_linerangeh(aes_q(xmin=as.name(paste0("25%", x)),
      xmax=as.name(paste0("75%", x))), size=1) +
    # 50% point
    geom_point() +
    xlab(paste(x, names[1], sep=": ")) +
    ylab(paste(y, names[2], sep=": ")) 

  return(p)
}
# }}}

# plotTOs {{{

#' plotTOs(perq, "S1", "T1", "2028") + xlim(c(0, 0.30)) + ylim(c(0.5, 1.5))
plotTOs <- function(data, x, y, year=max(data$year), alpha=0.5, colkey="mp") {
  
  # HACK: scoping issue in data.table due to match arg & col names
  ye <- year
  
  dat <- data[indicator %in% c(x, y),][year %in% ye,]
  names <- unique(dat[indicator %in% c(x, y), name])
  
  # TURN run and mp (if it exists) into character
  dat[, 'run' := lapply(.SD, as.character), .SDcols='run']
  if("mp" %in% names(dat)) {
    dat[, mp := lapply(.SD, as.character), .SDcols='mp']

    dat <- dcast(dat, year + run + mp ~ indicator, sep="",
      value.var=c('10%','25%','50%','75%','90%'))
  } else {
    dat <- dcast(dat, year + run ~ indicator, sep="",
      value.var=c('10%','25%','50%','75%','90%'))
  }
  
  p <- ggplot(dat, aes_q(x=as.name(paste0("50%", x)),
      y=as.name(paste0("50%", y)), group=as.name(colkey), colour=as.name(colkey))) +
    # vertical lines
    geom_linerange(aes_q(ymin=as.name(paste0("10%", y)),
      ymax=as.name(paste0("90%", y))), alpha=alpha) +
    geom_linerange(aes_q(ymin=as.name(paste0("25%", y)),
      ymax=as.name(paste0("75%", y))), size=1, alpha=alpha) +
    # horizontal lines
    ggstance::geom_linerangeh(aes_q(xmin=as.name(paste0("10%", x)),
      xmax=as.name(paste0("90%", x))), alpha=alpha) +
    ggstance::geom_linerangeh(aes_q(xmin=as.name(paste0("25%", x)),
      xmax=as.name(paste0("75%", x))), size=1, alpha=alpha) +
    # 50% point
    geom_point(aes_q(), alpha=alpha) + scale_shape(solid=FALSE) +
    xlab(paste(x, names[1], sep=": ")) +
    ylab(paste(y, names[2], sep=": ")) 
  
  return(p)
}
# }}}

# plotPTS {{{
plotPTS <- function(x, refpts, start) { 

  # EXTRACT metrics
	dat <- FLQuants(`Status (SB/SBMSY)`=ssb(x) %/% refpts['SBMSY'],
    Catch=catch(x))

  dat <- data.table(as.data.frame(dat, drop=TRUE), key=c("year", "iter", "qname"))

  # FIND its as 25,50,75 quantiles of sum(SB/SBMSY) over start:end
  its <- dat[iter %in% dat[year %in% seq(start, 2037)][qname == "Status (SB/SBMSY)"][,
    list(status=sum(data)), by=iter][order(status)][
    floor(length(levels(dat$iter)) / 100 * c(25, 50, 75))]$iter]

  # CALCULATE quantiles
  dat <- dat[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9), na.rm=TRUE)),
  keyby=list(year, qname)]

  p <- ggplot(dat, aes_q(x=quote(year), y=as.name("50%"))) +
    # START of simulations
    geom_vline(xintercept=start, size=0.4, linetype=2, alpha=0.6) +
    # 10-90%
    geom_ribbon(aes_q(x=quote(year), ymin=as.name("10%"), ymax=as.name("90%")),
      fill="gray", alpha=0.6) +
    # 25-75%
    geom_ribbon(aes_q(x=quote(year), ymin=as.name("25%"), ymax=as.name("75%")),
      fill="gray", alpha=0.8) +
    facet_grid(qname~., scale="free") +
    # LABs and LIMs
    ylab("") + xlab("") + ylim(c(0, NA)) +
    # 50%
    geom_line() +
    # 3 RUNS
    geom_line(data=its, aes(x=year, y=data, colour=iter), size=0.4) +
    # REFPTS lines
    geom_hline(aes(yintercept = 1), data=data.frame(qname="Status (SB/SBMSY)"),
      colour="darkgreen", size=0.3, linetype=2) +
    geom_hline(aes(yintercept = 0.4), data=data.frame(qname="Status (SB/SBMSY)"),
      colour="red", size=0.3, linetype=2) +
    # THEME
    theme(legend.position="none")

  return(p)
} # }}}

# plotUS {{{
plotUS <- function(set, param, indicator) {

  # 
  dat <- set[indicator=="S1",]
  
  # CALCULATE quantiles
  dat <- 
    dat[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9), na.rm=TRUE)),
  keyby=list(responsiveness)]

  ggplot(dat, aes_q(x=reponsiveness, y=)) + geom_point()

  return(p)
} # }}}

# plotOMR {{{
plotOMR <- function(om, runs, refpts, qname="ssb",
  ylab=paste0(toupper(qname), " (", units(qua), ")")) {

  # GET element, slot or method
  foo <- get(qname)

  if(!missing(refpts)) {
    qua <- foo(om) %/% refpts
    quas <- lapply(runs, function(x) foo(x) %/% refpts)
  } else {
    qua <- foo(om)
    quas <- lapply(runs, foo)
  }

  p1 <- plot(qua) + ylab(ylab) +
    geom_vline(xintercept=as.numeric(ISOdate(dims(qua)$maxyear,1,1)), linetype=2, colour='darkgrey')

  p2 <- plot(quas) + facet_wrap(~qname) + ylab(ylab) +
    geom_vline(xintercept=as.numeric(ISOdate(dims(qua)$maxyear,1,1)), linetype=2, colour='darkgrey')

  if(!missing(refpts)) {
    p1 <- p1 + geom_hline(aes(yintercept=1), linetype=2) 
    p2 <- p2 + geom_hline(aes(yintercept=1), linetype=2) 
  }

  # TODO DO with grid.arrange
  grid::pushViewport(grid::viewport(layout = grid::grid.layout(4, 2)))
  vplayout <- function(x, y) grid::viewport(layout.pos.row = x, layout.pos.col = y)
  print(p1, vp = vplayout(1, 1:2))
  print(p2, vp = vplayout(2:4, 1:2))

  invisible()
} # }}}

# plotOMRF {{{
plotOMRF <- function(om, runs, refpts, qname="ssb",
  ylab=paste0(toupper(qname), " (", units(om), ")")) {
  
  if(!missing(refpts)) {
    om <- om %/% refpts
    runs <- lapply(runs, `%/%`, refpts)
  }

  p1 <- plot(om) + ylab(ylab) +
    geom_vline(xintercept=as.numeric(ISOdate(dims(om)$maxyear,1,1)), linetype=2, colour='darkgrey')

  p2 <- plot(FLQuants(runs)) + facet_wrap(~qname) + ylab(ylab) +
    geom_vline(xintercept=as.numeric(ISOdate(dims(om)$maxyear,1,1)), linetype=2, colour='darkgrey')

  if(!missing(refpts)) {
    p1 <- p1 + geom_hline(aes(yintercept=1), linetype=2) 
    p2 <- p2 + geom_hline(aes(yintercept=1), linetype=2) 
  }

  # TODO DO with grid.arrange
  grid::pushViewport(grid::viewport(layout = grid::grid.layout(4, 2)))
  vplayout <- function(x, y) grid::viewport(layout.pos.row = x, layout.pos.col = y)
  print(p1, vp = vplayout(1, 1:2))
  print(p2, vp = vplayout(2:4, 1:2))

  invisible()
} # }}}
