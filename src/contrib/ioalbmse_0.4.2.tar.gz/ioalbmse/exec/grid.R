# tune.R - DESC
# ioalbmse/exec/tune.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

library(doParallel)
registerDoParallel(detectCores()-2)

# Setup
data(om)
data(indicators)

years <- seq(2015, length=21)
omp <- fwdWindow(om, end=tail(years, 1) + 9, br)

# -- CONSTANT CATCH
cc <- FLCore::expand(catch(base)[,'2012'], year=seq(2013, 2044))

Rcc <- fwd(omp, asfwdControl(catch=cc), sr=sro)

# -- CONSTANT F
cf <- FLCore::expand(fbar(base)[,'2012'], year=seq(2013, 2044))

Rcf <- fwd(omp, asfwdControl(f=cf), sr=sro)

# plot(Rcc, Rcf)

performance(Rcf, indicators, refpts, year=2035)

cons <- performance(FLStocks(CF=Rcf, CC=Rcc), indicators, refpts, year=2035)
cons[, "mp" := run]
cons[, run := "R1"]
setcolorder(cons, c(length(cons), 1:(length(cons)-1)))

conq <- cons[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9))),
  keyby=list(mp, indicator, name, year, run)]


# -- IRATE

# GRID
igrid <- list(
  # PARAMS
  responsiveness=seq(0.4, 0.6, length=2),
  hr_multiplier=seq(0.5, 1.2, length=2),
  biomass_threshold=seq(0.2, 0.4, length=2),
  biomass_limit=seq(0.3, 0.5, length=2),
  maxTAC=seq(3e5, 4e5, length=2),
  # TIMING
  SFREQ=seq(1,2),
  DLAG=seq(1,2))


# RUN
iruns <- doRuns(IRate, om=omp, sr=sro, years=years, grid=igrid,
  yref=1980:2010, errcpue=~rnorm(mean=0, sd=cpue * 0.20),
  effcpue=~0, srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)), MLAG=2)

iperf <- rbindlist(mclapply(iruns, performance, indicators, refpts,
  mc.cores=detectCores()-1), idcol='run')
iperf[, "mp" := "irate"]

setcolorder(iperf, c(length(iperf), 1:(length(iperf)-1)))

iperq <- iperf[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9))),
  keyby=list(mp, indicator, name, year, run)]

save(iruns, iperf, iperq, file="irateruns.RData", compress="xz", compression_level=9)

save(iperq, file="irateperq.RData", compress="xz", compression_level=9)


# -- BRULE

# GRID
bgrid <- list(
  # PARAMS
  bthreshold=seq(0.8, 1.2, by=0.05),
  # TIMING
  SFREQ=seq(2,3),
  DLAG=seq(1,2))

# RUN
bruns <- doRuns(BRule, om=omp, sr=sro, years=years, grid=bgrid,
  blim=0.4*refpts['SBMSY'], ftarget=refpts['FMSY'], bmsy=refpts['SBMSY',],
  MLAG=2, errcpue=~rnorm(mean=0, sd=cpue * 0.20),
  effcpue=~0, srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)))

bperf <- rbindlist(mclapply(bruns$runs, performance, refpts, indicators,
  mc.cores=62), idcol='run')
bperf[, "mp" := "brule"]
setcolorder(bperf, c(length(bperf), 1:(length(bperf)-1)))

bperq <- bperf[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9))),
  keyby=list(mp, indicator, name, year, run)]

save(bruns, bperf, bperq, file="bruleruns.RData", compress="xz", compression_level=9)

save(bperq, file="bruleperq.RData", compress="xz", compression_level=9)


# -- AGGREGATE performance

perq <- rbindlist(list(conq, iperq, bperq))

save(perq, file="perq.RData", compress="xz", compression_level=9)
