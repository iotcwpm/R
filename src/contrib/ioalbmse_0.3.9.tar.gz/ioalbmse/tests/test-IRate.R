# test-IRate.R - DESC
# /test-IRate.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

set.seed(2016)

# --- SETUP

# LOAD data
data(om)
data(base)
data(indicators)

# MSE YEARS
years <- seq(2015, length=30)

# OMP: tail + 10
idx <- sample(seq(dims(om)$iter), 50)
omp <- fwdWindow(iter(om,idx), end=tail(years, 1) + 5, iter(br, idx))
sro$params <- iter(sro$params, idx)

# HISTORIC levels, CPUE from 1980
mcpue <- yearMeans(window(ssb(omp), start=1980, end=2012)/1000)
mcatch <- yearMeans(window(catch(omp), start=1980, end=2012))
mhrmult <- yearMeans(window(catch(omp), start=1980, end=2012) /
  (window(ssb(omp), start=1980, end=2012)/1000)) 

# -- RUN 0

system.time(
  R0 <- IRate(omp, sr=sro, years=years,
  responsiveness=0.5, hr_multiplier=1.0,
  biomass_threshold=0.5, biomass_limit=0.2, maxTAC=400000,
  errcpue=~rnorm(mean=0, sd=cpue * 0.10),
  srresiduals=exp(FLife::noise(1,
    FLQuant(0, dimnames=list(year=seq(years[1], tail(years, 1) + 6))), sd=0.2, b=0.1)),
  effcpue=~0,
  DLAG=1, MLAG=2, SFREQ=3, verbose=TRUE)
)

system.time(
  iR0 <- performance(window(R0, start=2017), indicators, refpts[,idx],
  years=2017 + c(1,5,10,20))
)


