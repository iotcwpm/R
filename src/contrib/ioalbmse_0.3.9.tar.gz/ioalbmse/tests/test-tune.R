# test-tune.R - DESC
# /test-tune.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)
library(doMC)
# registerDoMC(4)

set.seed(2016)

# --- SETUP

# LOAD data
data(om)
data(base)
data(indicators)

# MSE YEARS
years <- seq(2015, length=30)

# OMP: tail + 10
idx <- sample(seq(dims(om)$iter), 50)
omp <- fwdWindow(FLCore::iter(om,idx), end=tail(years, 1) + 5, FLCore::iter(br, idx))
sro$params <- FLCore::iter(sro$params, idx)

# HISTORIC levels
mean_cpue <- yearMeans(window(ssb(omp), start=1980, end=2012)/1000)
mean_catch <- yearMeans(window(catch(omp), start=1980, end=2012))
mean_hr_mult <- yearMeans(window(catch(omp), start=1980, end=2012) /
  (window(ssb(omp), start=1980, end=2012)/1000)) 

# GRID
grid <- list(
  responsiveness=0.5,
  hr_multiplier=seq(0.8, 1.2, length=1),
  biomass_threshold=seq(0.2, 0.8, length=2),
  biomass_limit=seq(0.1, 0.4, length=2),
  maxTAC=300000
  )

# DORUNS

set <- doRuns(IRate, om=omp, sr=sro, years=years, grid=grid,
  verbose=TRUE)

#
perf <- rbindlist(lapply(set$runs, performance,
  indicators=indicators, refpts=refpts[,idx]), idcol='run')

# TUNE

tun <- tune(IRate, om=omp, sr=sro, years=years, grid=grid,
  indicators=indicators, refpts=refpts[,idx], verbose=FALSE)

tunq <- tun[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9))),
  keyby=list(mp, run, indicator, year)]
