# test-BRule.R - DESC
# /test-BRule.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

set.seed(2016)

# --- SETUP

# LOAD data
data(om)
data(base)
data(indicators)

# MSE YEARS
years <- seq(2015, length=30)

# OMP: tail + 10
idx <- sample(seq(dims(om)$iter), 50)
omp <- fwdWindow(iter(om,idx), end=tail(years, 1) + 5, iter(br, idx))
sro$params <- iter(sro$params, idx)

# -- RUN 0

system.time(
  R0 <- BRule(omp, sro, years,
    bthreshold=refpts['SBMSY',idx],
    blim=0.4*refpts['SBMSY',idx],
    bmsy=refpts['SBMSY',idx],
    ftarget=refpts['FMSY',idx],
    DLAG=1, MLAG=1, SFREQ=1,
    errcpue=~0, effcpue=~0, srresiduals=~1, errimp=~0, 
    verbose=TRUE)
)

