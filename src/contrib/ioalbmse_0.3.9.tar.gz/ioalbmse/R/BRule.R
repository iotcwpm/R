# BRule.R - Function implementing the BRule MP
# ioalbmse/R/BRule.R

# Copyright European Union, 2013-2016
# Authors: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#          Finlay Scott (EC JRC) <finlay.scott@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

# TODO Parse FLQ args for tune, e.g. bthreshold & bmsy

# BRule {{{

#' Run the BRule Management Procedure
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend
#' odio ac rutrum luctus. Aenean placerat porttitor commodo. Pellentesque eget porta
#' libero. Pellentesque molestie mi sed orci feugiat, non mollis enim tristique. 
#' Suspendisse eu sapien vitae arcu lobortis ultrices vitae ac velit. Curabitur id 
#' nunc euismod ante fringilla lobortis. Aliquam ullamcorper in diam non placerat. 
#'
#  -- INPUTS
#' @param omp An FLStock object with the extended OM
#' @param sr A list with SR params and model, to be passed to fwd()
#  -- PARAMS
#' @param responsiveness
#  -- TIMING
#' @param years For which years is the simulation to be run?
#' @param DLAG
#' @param MLAG
#' @param SFREQ
#  -- ERROR
#' @param errorcpue
#' @param effcpue
#' @param errorcpue
#' @param srresiduals
#' @param errimp
#  -- EXTRA
#' @param verbose Should progress be reported on screen? Defaults to TRUE
#'
#' @return FLStock
#'
#' @name BRule
#' @rdname BRule
#' @aliases BRule BRule
#'
#' @author Iago Mosqueira, EC JRC
#' @seealso \code{\link{FLStock}}
#' @keywords utilities
#' @examples
#'
#' omp <- fwdWindow(om, end=dims(om)$maxyear + 3, br)

BRule <- function(omp, sr, years, bthreshold, blim, ftarget, bmsy,
 DLAG=1, MLAG=1, SFREQ=1, errcpue=~0, effcpue=~0, srresiduals=~1, errimp=~0, 
 verbose=FALSE) {

  sel <- sel(omp)

  bthreshold <- bthreshold * bmsy

  # PB
  if(verbose)
    pb <- utils::txtProgressBar(min = years[1], max = years[length(years)],
      initial = 1, style=3, title="Years:")

  for (y in years[seq.int(1L, length(years), SFREQ)]) {

    # Get catch data, no error
    tc <- window(catch(omp), end=y - DLAG)

    # Get CPUE
    # TODO USE real cpue for historic period
    cpue <- vb(x=window(omp, end=y - DLAG), sel=window(sel, end= y - DLAG)) / 1000

    # CPUE ERROR
    cpue <- cpue + eval(errcpue[[2]])

    # CPUE EFFICIENCY BIAS
    cpue <- cpue + eval(effcpue[[2]])

    # RUN bd model
    # TODO ADD call to biodyn bd(tc, cpue)
    eb <- stock(omp)[,ac(y-DLAG)]

    # SET TAC for next SFREQ years, starting in y + MLAG
    taf <- FLCore::expand(fbar(omp)[,ac(y-1)], year=seq(y + MLAG, y + MLAG + SFREQ - 1))
    
    # IF EB < BLIM, F = 0
    taf[,,,,,c(eb) <= c(blim)] <- 0.02
    # IF EB >= BTHRESHOLD, F = Ftarget
    taf[,,,,,c(eb) >= c(bthreshold)] <- c(ftarget[,c(eb) >= c(bthreshold)])
    # ELSE F = f()
    idx <- c(eb) < c(bthreshold) & c(eb) > c(blim)
    taf[,,,,,idx] <- 
      fbar(omp)[,ac(y-DLAG),,,,idx] /
      (bthreshold[,idx] - blim[,idx]) * (eb[,,,,,idx] - blim[,idx])

    # IMPLEMENTATION error
    # nc <- tac + eval(errimp[[2]])

    # Parse srresiduals
    if(is(srresiduals, "formula")) {
      sr.residuals <- eval(srresiduals[[2]]) +
        FLQuant(0, dimnames=c(dimnames(taf)[-2],
          list(year=seq(y + MLAG, y + MLAG + SFREQ - 1))))
    }
    else {
      sr.residuals <- srresiduals[, ac(seq(y + MLAG, y + MLAG + SFREQ - 1))]
    }

    # Project om
    omp <- fwd(omp, asfwdControl(f=taf),
      sr=sr, sr.residuals=sr.residuals, sr.residuals.mult=TRUE)

    # PRINT
    if(verbose)
      setTxtProgressBar(pb, y)
  }
  return(window(omp, start=years[1]-1, end=y))
} # }}}
