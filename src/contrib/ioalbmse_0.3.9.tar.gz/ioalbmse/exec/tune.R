# tune.R - DESC
# ioalbmse/exec/tune.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

library(doParallel)
registerDoParallel(detectCores()-1)

# Setup
data(om)
data(indicators)

years <- seq(2015, length=21)
omp <- fwdWindow(om, end=tail(years, 1) + 9, br)


# -- IRATE

# GRID
igrid <- list(
  # PARAMS
  responsiveness=seq(0.4, 0.6, by=0.1),
  hr_multiplier=seq(0.6, 1.4, by=0.1),
  biomass_threshold=seq(0.2, 0.4, by=0.1),
  biomass_limit=seq(0.3, 0.5, by=0.1),
  maxTAC=seq(3e5, 4e5, length=5),
  # TIMING
  SFREQ=seq(2,3),
  DLAG=seq(1,2))

# TUNE
itun <- tune(IRate, om=omp, sr=sro, years=years, grid=igrid,
  refpts=refpts, indicators=indicators, verbose=FALSE,
  yref=1980:2010, errcpue=~rnorm(mean=0, sd=cpue * 0.20),
  effcpue=~0, srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)), MLAG=2)

itunq <- tun[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9))),
  keyby=list(mp, indicator, name, year, run)]

save(itun, itunq, file="iratetune.RData", compress="xz", compression_level=9)

# -- BRULE

# GRID
bgrid <- list(
  # PARAMS
  bthreshold=seq(0.8, 1.2, by=0.05),
  # TIMING
  SFREQ=seq(2,3),
  DLAG=seq(1,2))
