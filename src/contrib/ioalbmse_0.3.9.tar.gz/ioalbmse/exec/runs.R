# test-IRate.R - DESC
# ioalbmse/exec/test-IRate.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

set.seed(2016)

# --- SETUP

# LOAD data
data(om)
data(indicators)

# MSE YEARS
years <- seq(2015, 2037)

# OMP: tail + 10
omp <- fwdWindow(om, end=tail(years, 1) + 8, br)

# BASE args

args <- list(
  yref=seq(1981, 2010),
  # PARAMS
  responsiveness=0.5, hr_multiplier=1.1,
  biomass_threshold=0.5, biomass_limit=0.2,
  maxTAC=400000,
  # ERROR
  errcpue=~rnorm(mean=0, sd=cpue * 0.10),
  effcpue=~0,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.2, b=0.1)),
  # TIMING
  DLAG=2, MLAG=2, SFREQ=2)

# -- CONSTANT CATCH
cc <- FLCore::expand(catch(omp)[,'2012'], year=seq(2013, 2044))

Rcc <- fwd(omp, asfwdControl(catch=cc), sr=sro)

# -- CONSTANT F
cf <- FLCore::expand(fbar(omp)[,'2012'], year=seq(2013, 2044))

Rcf <- fwd(omp, asfwdControl(f=cf), sr=sro)

# -- RUN 0

R0 <- do.call(IRate, c(list(omp=omp, sr=sro, year=years), args))

# -- RUNS responsiveness

args$responsiveness <- 0.3
Rre03 <- do.call(IRate, c(list(omp=omp, sr=sro, year=years), args))

args$responsiveness <- 0.7
Rre07 <- do.call(IRate, c(list(omp=omp, sr=sro, year=years), args))

# -- RUNS hrmultiplier

args$responsiveness <- 0.5
args$hr_multiplier <- 0.9
Rhr09 <- do.call(IRate, c(list(omp=omp, sr=sro, year=years), args))

args$hr_multiplier <- 1.3
Rhr13 <- do.call(IRate, c(list(omp=omp, sr=sro, year=years), args))

# -- RUNS
runs <- window(FLStocks(R0=R0, Rre03=Rre03, Rre07=Rre07, Rhr09=Rhr09,
  Rhr13=Rhr13), end=2035)


BRule(omp, sr=sro, years=years, bthreshold=1, blim=0.4*refpts['SBMSY'],
  ftarget=refpts['FMSY'], bmsy=refpts['SBMSY',],  
  DLAG=2, MLAG=2, SFREQ=2,
  errcpue=~rnorm(mean=0, sd=cpue * 0.20), effcpue=~0, errimp=~0,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)))


# plots

plotOMR(om, runs[1:4])

# performance
perf <- performance(window(runs, start=2015), indicators, refpts,
  years=c(2017, 2021, 2027, 2035))

# quantiles
perq <- perf[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9), na.rm=TRUE)),
  keyby=list(mp, run, indicator, year, name)]

# plots
plotTOs(perq, "S1", "T1", "2035", colkey="run")
plotTOs(pperq, "S1", "T1", "2035", colkey="mp")

save(runs, perf, perq, file="runs.RData", compress="xz")
