# perturbation.R - DESC
# /perturbation.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.


library(ioalbmse)
library(doMC)
registerDoMC(6)

# SETUP
data(om)
data(indicators)

years <- seq(2015, length=21)
omp <- fwdWindow(om, end=tail(years, 1) + 9, br)

# -- CONSTANT CATCH
cc <- FLCore::expand(catch(base)[,'2012'], year=seq(2013, 2044))

Rcc <- fwd(omp, asfwdControl(catch=cc), sr=sro)

# -- CONSTANT F
cf <- FLCore::expand(fbar(base)[,'2012'], year=seq(2013, 2044))

Rcf <- fwd(omp, asfwdControl(f=cf), sr=sro)

# -- PERTURB IRate

R1 <- IRate(om=omp, sr=sro, years=years,
  responsiveness=0.5,
  hr_multiplier=1,
  biomass_threshold=0.4,
  biomass_limit=0.5,
  maxTAC=4e5,
  SFREQ=2,
  DLAG=2,
  yref=1980:2010,
  errcpue=~rnorm(mean=0, sd=cpue * 0.20),
  effcpue=~0,
  srresiduals=exp(FLife::noise(1,
    FLQuant(0, dimnames=list(year=seq(years[1], tail(years, 1) + 6))), sd=0.3, b=0.2)),
  MLAG=2)




# -- PERTURB BRule
