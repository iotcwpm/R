# harvest.R - DESC
# /harvest.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

# harvest {{{
setMethod("harvest", signature(object="FLQuant", catch="FLQuant"),
  function(object, catch, m) {
    
    har <- m
    har[] <- NA

    dm <- dim(har)
    aa <- seq(1, dm[1] - 2)
    yy <- seq(1, dm[2] - 1)

    # YEARLY
    if(dm[4] == 1) {

      return(TRUE)
      
    # SEASONS
    } else {

      # seasons 1:3
      ss <- seq(1, dm[4] - 1)
      n0 <- object[,,,ss]
      n1 <- object[,,,ss + 1]
      har[,,,ss] <- log(n0/n1) - m[,,,ss]

      # season 4
      n0 <- object[aa,yy,,dm[4]]
      n1 <- object[aa + 1,yy + 1,,1]
      har[aa,yy,,dm[4]] <- log(n0/n1) - m[aa,yy,,dm[4]]

      # DIV/0 to 0
      har[har < 0] <- 0

      # Q & D, 1999 (Page 325)
      # C_y,a = N_y,a * (F_y,a / (F_y,a + M_y,a)) * (1 - exp((-F_y,a - M_y,a) * tau))
      # NOTE: IGNORING tau (no. years represented by pgroup)
      
      # MINIMIZES diff in catch
      foo <- function(logf, n, c, m, ratio) {
        f <- exp(logf)
        ch <- (f / (f + m)) * (1 - exp(-f - m)) * n
        cr <- (c - ch)
        return(cr^2)
      }

      # LOOP over units
      for(u in seq(dm[3])) {
        # LOOP over years and last 2 ages
        for(y in seq(dm[2]-1)) {
          for(a in c(dm[1]-1, dm[1])) {
            res <- optimize(f=foo, interval = log(c(1e-8,3)),
              n=c(object[a,y,u,4]),
              c=c(catch[a,y,u,4]),
              m=c(m[a,y,u,4]))$minimum
            har[a,y,u,4] <- exp(res)
          }
        }
        # LOOP over ages for last year and season
        for(a in seq(dm[1])) {
          res <- optimize(f=foo, interval = log(c(1e-8,3)),
            n=c(object[a,dm[2],u,4]),
            c=c(catch[a,dm[2],u,4]),
            m=c(m[a,dm[2],u,4]))$minimum
          har[a,dm[2],u,4] <- exp(res)
        }
      }
    }
    har[is.na(har)] <- 0
    units(har) <- "f"

    return(har)
  }
) # }}}
