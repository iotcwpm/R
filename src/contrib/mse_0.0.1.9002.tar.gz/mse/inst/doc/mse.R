## ---- pkgs, echo=FALSE, message=FALSE------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")
library(FLCore)
# LOAD other packages, including FLPKG, here

## ---- devtools, echo=TRUE, eval=FALSE------------------------------------
#  	library(devtools)
#  	install_github('iagomosqueira/mse')

