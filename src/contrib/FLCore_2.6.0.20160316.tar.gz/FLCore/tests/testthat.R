library(testthat)
library(FLCore)

test_check("FLCore")
