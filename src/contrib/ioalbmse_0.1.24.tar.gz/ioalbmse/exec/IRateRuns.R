# IRateRuns.R - DESC
# ioalbmse/exec/IRateRuns.R

# Copyright European Union, 2015-2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

# LOAD data
data(om)
data(indicators)

# VARIABLES
pyrs <- seq(2015, length=30 + 2)

# SETUP
omp <- fwdWindow(om, end=tail(pyrs, 1) + 2, br)

# UPDATE OM for 2013, 2014, NC from IOTC (2016)
nc <- FLQuant(c(33719.8034529015, 40091.187972784),
  dimnames=list(age='all', year=2013:2014))

omp <- fwd(omp, as.fwdControl(catch=nc), sr=sro)

# BRIDGE 'current' year with F=F_y-1
nf <- FLCore::expand(fbar(omp)[  ,'2014'], year=2015:2016)
omp <- fwd(omp, as.fwdControl(f=nf), sr=sro)

# HISTORIC levels, CPUE from 1980
mcpue <- yearMeans(window(ssb(omp), start=1980, end=2012)/1000)
mcatch <- yearMeans(window(catch(omp), start=1980, end=2012))
mhrmult <- yearMeans(window(catch(omp), start=1980, end=2012) /
  (window(ssb(omp), start=1980, end=2012)/1000)) 


# -- RUN 0
R0 <- IRate(omp, sr=sro, years=pyrs, responsiveness=0.5,
  hr_multiplier=1.1 * mhrmult,
  biomass_threshold=0.5 * mcpue,
  biomass_limit=0.2 * mcpue, maxTAC=400000,
  error=~0, residuals=~1, DLAG=1, MLAG=2, SFREQ=1,
  verbose=TRUE)

iR0 <- performance(window(R0, start=2017), refpts, indicators,
  years=c(2018, 2022, 2028, 2038))

# 

# RESIDUAL SCENARIOS

# EFFICIENCY: 0, 1, 2%

# IMPLEMENTATION ERROR: 10-30%

# -- ERROR levels

# RE2: 20%CV
RE2 <- IRate(omp, sr=sro, years=pyrs, responsiveness=0.5,
  hr_multiplier=1.1 * mhrmult,
  biomass_threshold=0.5 * mcpue,
  biomass_limit=0.2 * mcpue, maxTAC=400000,
  # error = ~rnorm(mean=0, sd=cpue*0.20)
  error=~rnorm(mean=0, sd=cpue*0.20), residuals=~1, DLAG=1, MLAG=2, SFREQ=1)

# RE3: 30%CV
RE3 <- IRate(omp, sr=sro, years=pyrs, responsiveness=0.5,
  hr_multiplier=1.1 * mhrmult,
  biomass_threshold=0.5 * mcpue,
  biomass_limit=0.2 * mcpue, maxTAC=400000,
  # error = ~rnorm(mean=0, sd=cpue*0.30)
  error=~rnorm(mean=0, sd=cpue*0.30), residuals=~1, DLAG=1, MLAG=2, SFREQ=1)

# RE4: 40%CV
RE4 <- IRate(omp, sr=sro, years=pyrs, responsiveness=0.5,
  hr_multiplier=1.1 * mhrmult,
  biomass_threshold=0.5 * mcpue,
  biomass_limit=0.2 * mcpue, maxTAC=400000,
  # error = ~rnorm(mean=0, sd=cpue*0.40)
  error=~rnorm(mean=0, sd=cpue*0.40), residuals=~1, DLAG=1, MLAG=2, SFREQ=1)

# RE5: 50%CV
RE5 <- IRate(omp, sr=sro, years=pyrs, responsiveness=0.5,
  hr_multiplier=1.1 * mhrmult,
  biomass_threshold=0.5 * mcpue,
  biomass_limit=0.2 * mcpue, maxTAC=400000,
  # error = ~rnorm(mean=0, sd=cpue*0.50)
  error=~rnorm(mean=0, sd=cpue*0.50), residuals=~1, DLAG=1, MLAG=2, SFREQ=1)


# RESID OM CV=20,30,40%
# AC


    # TODO 10-30% error, rnorm(n, mean~F(delta_TAC), SD)

# SUMMARY RUNS

runs <- FLStocks(R0=R0, RE2=RE2, RE3=RE3, RE4=RE4, RE5=RE5)

plot(R0) + geom_vline(xintercept=2015, linetype=2, colour='darkgray')

plot(runs) + geom_vline(xintercept=2015, linetype=2, colour='darkgray')

# performance
perf <- performance(window(runs, start=2015), refpts, indicators, years=c(2018, 2022, 2028, 2038))

# quantiles

# PLOT trade-offs w/quantiles across years



