# ---

ggplot(filter(tun, indicator=="Y1"), aes(x=data)) +
  geom_density(aes(group=as.factor(responsiveness), colour=responsiveness, fill=responsiveness), alpha=0.3)
ggplot(filter(tun, indicator=="Y1"), aes(x=data)) +
  geom_density(aes(group=as.factor(biomass_limit), colour=biomass_limit, fill=biomass_limit), alpha=0.3)
ggplot(filter(tun, indicator=="Y1"), aes(x=data)) +
  geom_density(aes(group=as.factor(biomass_threshold), colour=biomass_threshold, fill=biomass_threshold), alpha=0.3)
ggplot(filter(tun, indicator=="Y1"), aes(x=data)) +
  geom_density(aes(group=as.factor(hr_multiplier), colour=hr_multiplier, fill=hr_multiplier), alpha=0.3)

# tun SUMMARY
tus <- tun %>% group_by(indicator, responsiveness, hr_multiplier,
  biomass_threshold, biomass_limit) %>%
  summarise(q50=quantile(data, .50, na.rm=TRUE),
            q10=quantile(data, .10, na.rm=TRUE),
            q90=quantile(data, .90, na.rm=TRUE))

# MAIN indicators: S3, Y1, 


# Y1
y1 <- tus %>% filter(indicator == "Y1")

ggplot(tus %>% filter(indicator == "Y1"), aes(x=q50)) + geom_density()
ggplot(tus %>% filter(indicator == "S1"), aes(x=q50)) + geom_density()

y1[which.max(y1$q50),]

ggplot(y1, aes(x=biomass_limit)) + geom_point(aes(y=q50))
ggplot(y1, aes(x=biomass_threshold)) + geom_point(aes(y=q50))
ggplot(y1, aes(x=hr_multiplier)) + geom_point(aes(y=q50))
ggplot(y1, aes(x=biomass_threshold)) + geom_point(aes(y=q50))

p + facet_grid(responsiveness + hr_multiplier ~ biomass_threshold + biomass_limit)

ggplot(dat, aes(x=hr_multiplier, y=q50)) + geom_point()

