# test.R - DESC
# test.R

# Copyright 2015 Iago Mosqueira. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:


library(ioalbmse)

runapp()

refpts <- FLPar(
	B0=res$TotBio_Unfished,
	SB0=res$SPB_1950,
	MSY=res$TotYield_MSY,
	SBMSY=res$SSB_MSY,
	FMSY=res$Fstd_MSY,
	SBtarget=res$SSB_MSY,
	Ftarget=res$Fstd_MSY)

dimnames(refpts)$iter <- as.character(res$number)


shiny::runApp('./mseapp', display.mode="normal")


input <- list(Minp='0202', sigmaR=0.4)

sce <- res[,1:8]
sce[] <- lapply(sce, as.character)

idx <- sce[sce$M %in% input$Minp,]

subom <- om[,,,,,as.character(idx$number)]

subrefpts <- return(refpts[,subsce()$number])

subrefpts

plotTS(subom, refpts)


library(dygraphs)

dat <- as.data.frame(ssb(x), drop=TRUE, date=TRUE) %>%
		group_by(date) %>%
		summarize(min = min(data), max = max(data), median = median(data))

tdat <- xts(dat, order.by=dat$date)

dygraph(tdat) %>%
  dyAxis("x", drawGrid = FALSE) %>%
  dySeries(c("min", "median", "max")) %>%
  dyOptions(colors = RColorBrewer::brewer.pal(3, "Set1"))

