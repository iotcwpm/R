# test-IRate.R - DESC
# /test-IRate.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

set.seed(2016)

# --- SETUP

# LOAD data
data(om)
data(indicators)

# SR residuals from 1981
sresid <- residuals(window(om, start=1981), sro[['formula']], sro[['params']])

# MSE YEARS
years <- seq(2015, length=21)

# OMP: tail + MLAG + SFREQ
omp <- fwdWindow(om, end=tail(years, 1) + 10, br)

# UPDATE OM for 2013, 2014, NC from IOTC (2016)
# TODO add sresid
nc <- FLQuant(c(33719.8034529015, 40091.187972784),
  dimnames=list(age='all', year=2013:2014))

omp <- fwd(omp, as.fwdControl(catch=nc), sr=sro)

# BRIDGE 'current' years with F=F_y-1
# TODO add sresid
nf <- FLCore::expand(fbar(omp)[  ,'2014'], year=2015:2016)
omp <- fwd(omp, as.fwdControl(f=nf), sr=sro)

# HISTORIC levels, CPUE from 1980
mcpue <- yearMeans(window(ssb(omp), start=1980, end=2012)/1000)
mcatch <- yearMeans(window(catch(omp), start=1980, end=2012))
mhrmult <- yearMeans(window(catch(omp), start=1980, end=2012) /
  (window(ssb(omp), start=1980, end=2012)/1000)) 

# -- RUN 0

system.time(
  R0 <- IRate(omp, sr=sro, years=years,
  responsiveness=0.5, hr_multiplier=1.1 * mhrmult,
  biomass_threshold=0.5 * mcpue, biomass_limit=0.2 * mcpue, maxTAC=400000,
  errcpue=~rnorm(mean=0, sd=cpue * 0.20),
  srresiduals=exp(noise(1,
    FLQuant(0, dimnames=list(year=seq(years[1], tail(years, 1) + 6))), sd=0.3, b=0.7)),
  effcpue=~cpue * 0.01,
  DLAG=1, MLAG=2, SFREQ=3, verbose=TRUE)
)

#  user  system elapsed 
# 69.428   0.161  69.348 

system.time(
  iR0 <- performance(window(R0, start=2017), refpts, indicators,
  years=c(2018, 2022, 2028, 2038))
)

#   user  system elapsed 
#  1.709   0.067   1.762 




