# load.R - DESC
# ioalbmse/R/load.R

# Copyright European Union, 2015-2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

# loadres(vars, dir, grid, progress=TRUE) {{{
loadres <- function(dir, grid, vars, progress=TRUE) {

	# out DF
	out <- do.call('data.frame', c(lapply(vars, rep, dim(grid)[1]),
		list(stringsAsFactors=FALSE, row.names=grid$number, check.names=FALSE)))

	# LOOP
	dirs <- paste(dir, grid$id, sep='/')

	# First outputs
	out[1,] <- readSS3Results(paste(dirs[1], "Report.sso", sep="/"), vars)

	# Loop over dirs
	for(i in seq(length(dirs))[-1]) {

		if(progress)
			cat(paste0('[', i, ']\n'))

		# Load model outputs
		out[i,] <- readSS3Results(paste(dirs[i], "Report.sso", sep="/"), vars)

	}

	# CHANGE SSB_MSY to both sexes
	out$SSB_MSY <- out$SSB_MSY * 2

	return(cbind(grid, out))
} # }}}

# loadom(dir, grid, progress=TRUE) {{{
loadom <- function(dir, grid, progress=TRUE) {

	# dirs
	dirs <- paste(dir, grid$id, sep='/')
	
	# First iter
	om <- readSS3Stock_iotc(paste(dirs[1], sep="/"))

	# Propagate
	om <- propagate(om, nrow(grid))


	# Loop over dirs (TODO foreach)
	for(i in seq(length(dirs))[-1]) {

		if(progress)
			cat(paste0('[', i, ']\n'))

		tmp <- readSS3Stock_iotc(dirs[i])
		om[,,,,,i] <- tmp
	}
	return(om)
} # }}}

# loadhessian {{{
loadhessian <- function(dir, grid) {

	dirs <- paste(dir, grid$id, sep='/')

	res <- vector('list', length=nrow(grid))
		names(res) <- grid$number

	for(i in grid$number) {

		filename <- file(paste(dir, grid$id[i], "admodel.hes", sep='/'), "rb")

  	num.pars <- readBin(filename, "integer", 1)
  	hes.vec <- readBin(filename, "numeric", num.pars^2)
  
		hes <- matrix(hes.vec, ncol=num.pars, nrow=num.pars)
  	hybrid_bounded_flag <- readBin(filename, "integer", 1)
  	scale <- readBin(filename, "numeric", num.pars)
  	
		res[[i]] <- list(num.pars = num.pars, hes = hes,
			hybrid_bounded_flag = hybrid_bounded_flag, scale = scale)

		close(filename)
	}

	return(res)

} # }}}

# getRange {{{
getRange <- function(x) {
	# empty range
	range <- rep(as.numeric(NA), 7)
	names(range) <- c("min", "max", "plusgroup", "minyear", "maxyear", "minfbar", "maxfbar")
	# age range from Catch
	range[c("min", "max")] <- range(as.numeric(names(x$c)[-(1:10)]))
	# plusgroup = max
	range["plusgroup"] <- range["max"]
	# min/maxfbar = min/max
	range[c("minfbar", "maxfbar")] <- range[c("min",    "max")]
	# year range from Catch
	range[c("minyear", "maxyear")] <- range(x$c$Yr)
	return(range)
} # }}}

# getDimnames {{{
getDimnames_iotc <- function(x, range=getRange(x)) {
    # dimnames: age and year
    dmns <- list(age=seq(range["min"], range["max"]),
        year=seq(range["minyear"],range["maxyear"]))
	# season
	if (x$season>1)
		dmns$season <- seq(x$season)  else dmns$season <- "unique"
	# unit - used to store birth season
	dmns$unit <- 1:4
	# area
	if (x$area>1)
		dmns$area <- seq(x$area)  else dmns$area <- "unique"
	# iter = 1
	dmns$iter = 1
	return(dmns)
} # }}}

# deSeason {{{
deSeason <- function(object, spwnSeason=1, stockSeason=1) {

	# ADD catch/landings/discards.n across seasons
	catch.n <- seasonSums(catch.n(object))
	landings.n <- seasonSums(landings.n(object))
	discards.n <- seasonSums(discards.n(object))

	# AVERAGE catch/landings/discards.wt across seasons weighted by *.n
	catch.wt <- seasonSums(catch.wt(object) * catch.n(object)) / seasonSums(catch.n(object))
	landings.wt <- seasonSums(landings.wt(object) * landings.n(object)) / seasonSums(landings.n(object))
	discards.wt <- seasonSums(discards.wt(object) * discards.n(object)) / seasonSums(discards.n(object))

	# EXTRACT stock.n/wt at start of year
	stock.n <- stock.n(object)[,,,stockSeason]
	dimnames(stock.n)$season <- 'all'
	# Set age-0 stock.n to be from spwnSeason
	stock.n[1,] <- stock.n(object)[1,,,spwnSeason]
	stock.wt <- stock.wt(object)[,,,stockSeason]
	dimnames(stock.wt)$season <- 'all'

	# EXTRACT mat, harvest.spwn, m.spwn from season 1
	mat <- mat(object)[,,,spwnSeason]
	dimnames(mat)$season <- 'all'
	# TODO % F before spwnSeason
	harvest.spwn <- harvest.spwn(object)[,,,1]
	harvest.spwn[] <- (spwnSeason - 1) / dims(object)$season
	dimnames(harvest.spwn)$season <- 'all'
	# TODO % M before spwnSeason
	m.spwn <- m.spwn(object)[,,,1]
	m.spwn[] <- (spwnSeason - 1) / dims(object)$season
	dimnames(m.spwn)$season <- 'all'

	# ADD harvest and m across seasons
	# TODO CHECK units == "f"
	harvest <- seasonSums(harvest(object))
	m <- seasonSums(m(object))
	# CORRECT m for age0 is spwnSeason > 1
	m[1,] <- m[1,] / spwnSeason

	# CREATE FLStock
	res <- FLStock(catch.n=catch.n, landings.n=landings.n, discards.n=discards.n,
		catch.wt=catch.wt, landings.wt=landings.wt, discards.wt=discards.wt,
		stock.n=stock.n, stock.wt=stock.wt, harvest=harvest,
		m=m, m.spwn=m.spwn, harvest.spwn=harvest.spwn, mat=mat)

	landings(res) <- computeLandings(res)
	discards(res) <- computeDiscards(res)
	catch(res) <-  computeCatch(res)
	stock(res) <- computeStock(res)

	return(res)

} # }}}
