# test-tune.R - DESC
# /test-tune.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)
# library(doMC)
# registerDoMC(4)

# Setup
data(om)
data(indicators)

years <- seq(2012, length=6)
omp <- fwdWindow(om, end=tail(years, 1) + 2, br)

# HISTORIC levels
mean_cpue <- yearMeans(window(ssb(omp), start=1980, end=2012)/1000)
mean_catch <- yearMeans(window(catch(omp), start=1980, end=2012))
mean_hr_mult <- yearMeans(window(catch(omp), start=1980, end=2012) /
  (window(ssb(omp), start=1980, end=2012)/1000)) 

# GRID
grid <- list(
  responsiveness=0.5,
  hr_multiplier=list(~ hr_multiplier * mean_hr_mult, hr_multiplier=seq(0.8, 1.2, length=2)),
  biomass_threshold=list(~ biomass_threshold * mean_cpue, biomass_threshold=seq(0.2, 0.8, length=2)),
  biomass_limit=list(~ biomass_limit * mean_cpue, biomass_limit=seq(0.1, 0.4, length=2)),
  maxTAC=300000)

tun <- tune(IRate, om=omp, sr=sro, years=years, grid=grid,
  refpts=refpts, indicators=indicators, verbose=FALSE)
