# makeOM.R - DESC
# ioalbmse/exec/makeOM.R

# Copyright 2015 Iago Mosqueira. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:

library(ioalbmse)

# USE doMC (multicore)

library(doMC)
registerDoMC(cores=62)

# SETUP scenarios {{{
sce <- list(
	# M
	M=c('0202', '0303', '0404', '0403', '0402'),
	# sigmaR
	sigmaR=c(0.4, 0.6),
	# steepness
	steepness=c(0.7, 0.8, 0.9),
	# CPUE CV 124 obs
	cpuecv=c(0.2, 0.3, 0.4, 0.5),
	# ESS 397 obs
	ess=c(20, 50, 100),
	# TWN LL q
	# Yearly multiplier for cpuecv
	llq=c('1.0000', '1.0025'),
	# TWN LL select
	# Logarithmic or DoubleNormal
	llsel=c("Log", "DoNorm")
) # }}}

# SETUP SS3 folders

grid <- setgrid(sce)

# SAVE grid object

save(grid, file='out/grid.RData')

# RUN SS3 grid

rungrid(grid, options='')

# LOAD FULL results

# vars: Name of parameter to extract from Report.sso + column number {{{
vars <- list(TotBio_Unfished=3, SPB_1950=3, SSB_MSY=3,
	SPB_2012=3, F_2012=3, Fstd_MSY=3,
	TotYield_MSY=3, `SR_LN(R0)`=3, LIKELIHOOD=4,
	Convergence_Level=2, Survey=28, Length_comp=2, Catch_like=2, Recruitment=2) # }}}

resF <- loadres(dir=dir, grid=grid, vars=vars)

omF <- loadom(dir=dir, grid=grid)
omF <- deSeason(omF)

save(omF, file=paste0('out/', dir, '/omF.RData'), compress='xz')
save(resF, file=paste0('out/', dir, '/resF.RData'), compress='xz')

# TRIM down om and res

# data.frame of K (t) vs. habitat size (km2) for all ALB stocks
prK <- data.frame(
	habitat=c(6073, 244, 3752, 7547, 3779, 7426),
	K=c(474828, NA, 3.576e+5, 3.982e5, 3.5e5, 307830))
dimnames(prK)[[1]] <- c("IO","MED","NAT","NPA","SAT","SPA")

# lm K ~ 0 + habitat
mod <- lm(K ~ 0 + habitat, prK)

# 99.9% CI for t/km2 ratio * IO ALB area (Arrizabalaga et al, 2015, doi: 10.1016/j.dsr2.2014.07.001)
cis <- confint(mod, level = 0.999) * 6073

# SUBSET om and res

idx <- resF$TotBio_Unfished <= cis[2]

res <- resF[idx,]
om <- omF[,,,,,idx]

# DROP age 0
om <- om[-1,,,,,]
range(om, c('plusgroup')) <- 14
range(om, c('minfbar', 'maxfbar')) <- c(5, 12)

# harvest < 0
harvest(om)[harvest(om) < 0] <- 0

# harvest/m.spwn
m.spwn(om) <- harvest.spwn(om) <- 0.75

# SR
# HACKED sr FLPar using params from shepherd
srp <- FLPar(a=res$steepness, b=exp(res$`SR_LN(R0)`), c=res$SPB_1950,
	iter=dim(res)[1])

sro <- list(model='shepherd', params=srp,
  formula=rec~(4 * a * b * ssb) / (c * (1 - a) + ssb * (5 * a - 1)))

# BRP
br <- FLBRP(om)

# SR residuals from 1981
sresid <- residuals(window(om, start=2000, end=2012), sro[['formula']], sro[['params']])

om <- fwdWindow(om, end=2017, br)

# UPDATE OM for 2013, 2014, NC from IOTC (2016)
nc <- FLQuant(c(33719.8034529015, 40091.187972784),
  dimnames=list(age='all', year=2013:2014))

sr.residuals <- sresid[,sample(dimnames(sresid)$year, 2, replace=TRUE)]
dimnames(sr.residuals) <- list(year=2013:2014)

om <- fwd(om, as.fwdControl(catch=nc), sr=sro, sr.residuals=sr.residuals)

# BRIDGE 'current' years with F=F_2014
nf <- FLCore::expand(fbar(om)[  ,'2014'], year=2015:2016)
sr.residuals <- sresid[,sample(dimnames(sresid)$year, 2, replace=TRUE)]
dimnames(sr.residuals) <- list(year=2015:2016)

om <- fwd(om, as.fwdControl(f=nf), sr=sro, sr.residuals=sr.residuals)

# CUT DOWN to 2016
om <- window(om, end=2016)

# SAVE om, sro, res, br

# save(om, sro, res, br, file=paste0('../data/om.RData'), compress='xz')
save(om, sro, res, br, file=paste0('out/', dir, '/om.RData'), compress='xz')

