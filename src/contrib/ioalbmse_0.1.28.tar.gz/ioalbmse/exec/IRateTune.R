# IRateTune.R - DESC
# /IRateTune.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

set.seed(2016)

# --- SETUP

# LOAD data
data(om)
data(indicators)

# SR residuals from 1981
sresid <- residuals(window(om, start=1981), sro$formula, sro$params)

# Years to extends OM object 
fyrs <- seq(2013, length=35)

# OMP
omp <- fwdWindow(om, end=tail(fyrs, 1), br)

# UPDATE OM for 2013, 2014, NC from IOTC (2016) TODO add sresid
nc <- FLQuant(c(33719.8034529015, 40091.187972784),
  dimnames=list(age='all', year=2013:2014))

omp <- fwd(omp, as.fwdControl(catch=nc), sr=sro)

# BRIDGE 'current' years with F=F_y-1 TODO add sresid
nf <- FLCore::expand(fbar(omp)[  ,'2014'], year=2015:2016)
omp <- fwd(omp, as.fwdControl(f=nf), sr=sro)

# HISTORIC levels, CPUE from 1980
mcpue <- yearMeans(window(ssb(omp), start=1980, end=2012)/1000)
mcatch <- yearMeans(window(catch(omp), start=1980, end=2012))
mhrmult <- yearMeans(window(catch(omp), start=1980, end=2012) /
  (window(ssb(omp), start=1980, end=2012)/1000)) 

# Years of mp application
mpyrs <- seq(2015, length=30)

# GRID
library(doMC)
registerDoMC(6)

grid <- list(
  responsiveness=seq(0.2, 0.6, by=0.1),
  hr_multiplier=list(~ hr_multiplier * mean_hr_mult, hr_multiplier=seq(0.8, 1.2, by=0.1)),
  biomass_threshold=list(~ biomass_threshold * mean_cpue, biomass_threshold=seq(0.2, 0.8, by=0.1)),
  biomass_limit=list(~ biomass_limit * mean_cpue, biomass_limit=seq(0.1, 0.4, by=0.1)),
  maxTAC=seq(300000, 500000, length=3))

tun <- tune(IRate, grid=grid, refpts=refpts, indicators=indicators,
  om=omp, sr=sro, years=mpyrs
  

save(tun, file="../data/iratetune.RData", compress="xz", compression_level=9)

