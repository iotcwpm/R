
# ioalbmse

Management Strategy Evaluation for the Indian Ocean Tuna Commission Albacore Tuna Stock

# PACKAGE MAP

.
├── data
│   ├── indicators.RData - indicators refpts
│   ├── iratetune.RData - tun
│   └── om.RData - om sro res brp
├── exec
│   ├── IRateRuns.R
│   ├── IRateTune.R
│   ├── makeOM.R
│   └── tmp.R
├── inst
│   └── shiny-apps
│       ├── mseapp
│       │   ├── global.R
│       │   ├── server.R
│       │   └── ui.R
│       └── test.R
├── R
│   ├── data.R
│   ├── fwdControl.R
│   ├── grid.R
│   ├── IRate.R
│   ├── load.R
│   ├── performance.R
│   ├── plots.R
│   ├── readSS3.R
│   ├── shiny.R
│   ├── tune.R
│   └── utilities.R
├── tests
│   ├── testthat
│   │   ├── test-IRate.R
│   │   └── test-tune.R
│   └── testthat.R
└── vignettes



# NOTES

- dygraph <https://rstudio.github.io/dygraphs/>
- shinydashboard <https://rstudio.github.io/shinydashboard/get_started.html>
- htmlwidgets <http://www.htmlwidgets.org/>

