# plots.R - DESC
# ioalbmse/R/plots.R

# Copyright European Union, 2015-2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

globalVariables("indicators")

# ploTS {{{
plotTS <- function(x, refpts) {

	dat <- FLQuants(`SSB (t)`=ssb(x) %/% refpts['SBMSY'],
									F=fbar(x) %/% refpts['FMSY'],
									Rec=rec(x))
	# refrpts lines
	line <- data.frame(qname=names(dat)[1:2], yintercept=c(1, 1))

	plot(dat) + geom_hline(data=line, aes(yintercept=yintercept), linetype=2, colour='black')
} # }}}

# plothistSSB {{{
plothistSSB <- function(x, year='2012') {

	dat <- ssb(x)[,as.character(year)]

	ggplot(dat, aes(x=data)) +
	geom_histogram(aes(y=..density..), fill='darkgrey', colour='black', binwidth=diff(range(dat)) / 20) +
	ylab("") + xlab("") +
  geom_density(alpha=.2, fill="#FF6666") +
	theme(axis.ticks.y=element_blank(), axis.text.y=element_blank(),
		plot.title = element_text(lineheight=.8, face="bold")) +
	ggtitle(expression(SSB[2012]))
} # }}}

# plotNSel {{{
plotNSel <- function(x, years=c(1950, 2012)) {

	dat <- as.data.frame(stock.n(x)[,as.character(years)], drop=TRUE) %>%
		group_by(year, age) %>%
		summarize(min = min(data), max = max(data), median = median(data))

	ggplot(as.data.frame(dat), aes(x=median, y=age, xmin=min, xmax=max)) +
		geom_errorbarh() +
		geom_point(aes(x=median)) +
		facet_grid(.~year) + 
		scale_y_reverse() +
		ylab("age") + xlab("") +
	theme(axis.ticks.x=element_blank(), axis.text.y=element_blank(),
		plot.title = element_text(lineheight=.8, face="bold")) +
	ggtitle("N at age")
} # }}}

# plotSR {{{
plotSR <- function(x) {

	dat <- model.frame(FLQuants(Rec=rec(x), SSB=ssb(x)), drop=TRUE)

	ggplot(dat, aes(x=SSB, y=Rec)) + geom_point(alpha=0.05) +
		ggtitle("Stock-recruit") + xlab("SSB (t)") + ylab("Recruits")
} # }}}

# labr {{{
labr <- function(variable, value) {
  return(paste(value, lapply(indicators, "[[", "name")[value]))
} # }}}

# plotTradeOffs {{{

#' plotTradeOffs(iR1q, "S1", "T1", "2028") + xlim(c(0, 0.30)) + ylim(c(0.5, 1.5))
plotTradeOffs <- function(data, x, y, year=max(data$year)) {

  # HACK: scoping issue in data.table due to match arg & col names
  ye <- year
  data <- data[.(c(x, y), ye)]

  # HACK: 2-row table to 1-row df with new colnames
  df <- cbind(as.data.frame(data[1,])[,-c(1,2,3)],
    as.data.frame(data[2,])[,-c(1,2,3)])
  names(df) <- sort(c(outer(c("X", "Y"), c(10, 25, 50, 75, 90), paste0)))

  p <- ggplot(df, aes(x=X50, y=Y50)) + geom_point() +
    geom_linerange(aes(ymin=Y10, ymax=Y90)) +
    geom_linerange(aes(ymin=Y25, ymax=Y75), size=1) +
    geom_linerangeh(aes(xmin=X10, xmax=X90)) +
    geom_linerangeh(aes(xmin=X25, xmax=X75), size=1) +
    xlab(paste(data[1,]$indicator, data[1,]$name, sep=": ")) +
    ylab(paste(data[2,]$indicator, data[2,]$name, sep=": ")) 

  return(p)
}
# }}}
