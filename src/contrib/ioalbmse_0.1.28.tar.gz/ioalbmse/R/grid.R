# grid.R - DESC
# ioalbmse/R/grid.R

# Copyright European Union, 2015-2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

# nameGrid {{{
#' nameGrid
#'
#' Creates folder names from a 'grid' df of scenarios
#'
nameGrid <- function(df, dir) {
	df$number <- seq(nrow(df))
	df$id <- paste(df$number, apply(df, 1, function(x)
		paste0(gsub(" ", "", paste0(names(x), as.character(x))), collapse="_")), sep="-")
	return(df)
}
# }}}

# setgrid {{{
setgrid <- function(sce, dir=paste0('grid', format(Sys.time(), "%Y%m%d")),
  base=system.file("sa/base", package="ioalbmse")) {

	# expand grid from sce
	grid <- nameGrid(expand.grid(sce, stringsAsFactors=FALSE))

	dir.create(dir)

	# SETUP grid
	foreach (i=grid$number, .errorhandling = "remove") %dopar% {
		
		# ctl file
		ctl <- readLines(paste(base, "/ss3.ctl", sep=""))

		# M
		linen <- grep("4 #_natM_type", ctl)
		ctl[linen+1] <- paste(c(
			seq(as.numeric(substr(as.character(grid[i,'M']), 1, 2))/10,
				as.numeric(substr(as.character(grid[i,'M']), 3, 4))/10, length=6),
			rep(as.numeric(substr(as.character(grid[i,'M']), 3, 4))/10 , 9)), collapse=" ")

		# sigmaR
		linen <- grep("# SR_sigmaR", ctl)
		a <- strsplit(ctl[linen],"\t")
		a[[1]][3:4] <- grid[i, "sigmaR"]
		a <- paste(unlist(a))
		ctl[linen] <- paste(unlist(a), collapse="\t")

		# steepness
		linen <- grep("# SR_BH_steep", ctl)
		a <- strsplit(ctl[linen], "\t")
		a[[1]][3:4] <- grid[i, "steepness"]
		ctl[linen] <- paste(unlist(a), collapse="\t")

		# TWN LL SEL
		# Logistic
		if(as.character(grid[i, "llsel"]) == 'Log') {
			linen <- grep("#_size_selex_types", ctl)
			ctl[linen+4] <- " 1 0 0 0 # 2 F2_TWN_LL_N"
			ctl[linen+8] <- " 1 0 0 0 # 6 F6_TW_LL_S"
		
			linen <- grep("# SizeSel_2P_1_F2_TWN_LL_N", ctl)
			ctl[linen] <- " 30 130 85 85 -1 99 2 0 0 0 0 0 0 0 # SizeSel_2P_1_F2_TWN_LL_N"
			ctl[linen+1] <- " 5 40 20 20 -1 99 3 0 0 0 0 0 0 0 # SizeSel_2P_2_F2_TWN_LL_N"
			ctl <- ctl[-seq(linen+2, length=4)] # *3
		
			linen <- grep("# SizeSel_6P_1_F6_TWN_LL_S", ctl)
			ctl[linen] <- " 30 130 85 85 -1 99 2 0 0 0 0 0 0 0 # SizeSel_6P_1_F6_TWN_LL_S"
			ctl[linen+1] <- " 5 40 20 20 -1 99 3 0 0 0 0 0 0 0 # SizeSel_6P_2_F6_TWN_LL_S"
			ctl <- ctl[-seq(linen+2, length=4)] # *3
		}
		# Double Normal: already in ss3.ctl
		
		# dat file
		dat <- readLines(paste(base,"ss3.dat", sep="/"))
		
		# cpuecv
		linen <- grep("#_year seas index      obs   se_log", dat)[1]
		nobs <- 371
		for(x in 1:nobs) {
			a <- strsplit(dat[linen + x], "\t")
			a[[1]][5] <- grid[i,"cpuecv"]
			dat[linen + x] <- paste(unlist(a), collapse=" ")
		}
		
		# ESS obs
		linen <- grep("#_Yr Seas FltSvy Gender Part Nsamp", dat)[1]
		nobs <- 664 # TODO Change
		for(x in 1:nobs) {
			a <- strsplit(dat[linen + x], "\t")
			a[[1]][6] <- grid[i, "ess"]
			dat[linen + x] <- paste(unlist(a), collapse="\t")
		}
		
		# TWN LL Q increases
		if(as.character(grid[i, "llq"]) != 1) {
			linen <- grep("#_year seas index *obs *se_log", dat)[1]
			nobs <- 371 # TODO Change
			cpue <- read.table(paste(base,"ss3.dat", sep="/"), nrows=nobs,
				skip = linen, sep="\t")
		
			cpue[,4] <- cpue[,4] / as.numeric(grid[i, "llq"]) ^ seq(0, nobs-1)
		
			dat[seq(linen + 1, length=nobs)]  <- apply(cpue, 1, function(x) paste(x, collapse="\t"))
		}
		
		#
		dirname <- paste(dir, grid[i, "id"], sep='/')

		# dir
		dir.create(dirname)

		# COPY unaltered files

		# starter.ss
		file.copy(paste(base, "starter.ss", sep="/"),
			paste(dirname, "starter.ss", sep="/"))
		
		# forecast.ss
		file.copy(paste(base, "forecast.ss", sep="/"),
			paste(dirname, "forecast.ss", sep="/"))

		# WRITE modified files

		# ctl
		write(ctl, paste(dirname, "ss3.ctl", sep="/"))
		# dat
		write(dat, paste(dirname, "ss3.dat", sep="/"))

		}

	invisible(grid)
	
} # }}}

# rungrid {{{
rungrid <- function(grid, dir=paste0('grid', format(Sys.time(), "%Y%m%d")),
  logfile=paste0(dir, '/run_grid_log'),
	options='-nohess') {
	
	cat("START: ", date(), "\n", file=logfile)

	foreach (i=grid$number, .errorhandling = "remove") %dopar% {

		dirname <- paste(dir, grid[i, "id"], sep="/")

		# SS3!
		workdir <- getwd()
		setwd(dirname)
		system(paste0("ss3", options))
		setwd(workdir)

		cat(grid[i,'id'], ": ", date(), "\n", file=logfile, append=TRUE)
	}

	cat("END: ", date(), "\n", file=logfile, append=TRUE)

	invisible(0)
} # }}}

