# tune.R - DESC
# ioalbmse/R/tune.R

# Copyright European Union, 2015-2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

globalVariables("i")

# tune {{{
tune <- function(mp, grid, refpts, indicators, ...) {
  
  # PARSE args
  args <- list(...)

  # CREATE grid, FIX names
  df <- do.call(data.table::CJ, lapply(grid,
    function(x) if(is.list(x)) x[[2]] else x))
  
  # CREATE progress bar
  pb <- txtProgressBar(min = 0, max = nrow(df), style = 3, title = "Runs:")

  # LOOP over grid rows
  out <- foreach(i = seq(nrow(df))) %dopar% {

    # EVAL formula, else single value
    inp <- lapply(grid, function(x) {
      if(is(x[[1]], "formula"))
        eval(as.list(x[[1]])[[2]], as.list(df[i,]))
      else
        x
    })

    # CALL mp
    run <- do.call(mp, c(args, inp))

    # UPDATE progress bar
    setTxtProgressBar(pb, i)
   
    cbind(performance(run, refpts, indicators), df[i,])
  }

  close(pb) 

  # JOIN out

  out <- data.table::rbindlist(out)

  return(out)
} # }}}
