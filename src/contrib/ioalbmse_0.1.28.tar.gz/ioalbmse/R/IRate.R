# IRate.R - Function implementing the IRate MP
# ioalbmse/R/IRate.R

# Copyright European Union, 2013-2016
# Authors: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#          Finlay Scott (EC JRC) <finlay.scott@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

# IRate {{{

#' Run the IRate Management Procedure
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend
#' odio ac rutrum luctus. Aenean placerat porttitor commodo. Pellentesque eget porta
#' libero. Pellentesque molestie mi sed orci feugiat, non mollis enim tristique. 
#' Suspendisse eu sapien vitae arcu lobortis ultrices vitae ac velit. Curabitur id 
#' nunc euismod ante fringilla lobortis. Aliquam ullamcorper in diam non placerat. 
#'
#' @param omp An FLStock object with the extended OM
#' @param sr A list with SR params and model, to be passed to fwd()
#' @param years For which years is the simulation to be run?
#' @param responsiveness
#' @param hr_multiplier
#' @param biomass_threshold
#' @param biomass_limit
#' @param maxTAC
#' @param DLAG
#' @param MLAG
#' @param error
#' @param residuals
#' @param verbose Should progress be reported on screen? Defaults to TRUE
#'
#' @return FLStock
#'
#' @name irate
#' @rdname irate
#' @aliases irate IRate
#'
#' @author Iago Mosqueira, EC JRC
#' @seealso \code{\link{FLStock}}
#' @keywords utilities
#' @examples
#'
#' data(om)
#' omp <- fwdWindow(om, end=dims(om)$maxyear + 3, br)
#'
#' mean_cpue <- yearMeans(window(ssb(om), start=1980, end=2012)/1000)
#' mean_catch <- yearMeans(window(catch(om), start=1980, end=2012))
#' mean_hr_mult <- yearMeans(window(catch(om), start=1980, end=2012) /
#'   (window(ssb(om), start=1980, end=2012)/1000)) 
#'
#' # Hindcast run
#' run <- IRate(omp, sro, 1990:2012, responsiveness=0.5,
#'   DLAG=1, MLAG=1, SFREQ=2,
#'   hr_multiplier= 1.1 * mean_hr_mult, biomass_threshold=0.5 * mean_cpue,
#'   biomass_limit=0.2 * mean_cpue, maxTAC=500000,
#'   srresiduals=~rlnorm(dims(om)$iter, 0, 0.5), verbose=FALSE)
#'
#' plot(window(FLStocks(run=run, om=om), end=2012))
#' 

IRate <- function(omp, sr, years, responsiveness, hr_multiplier,
  biomass_threshold, biomass_limit, maxTAC, DLAG=1, MLAG=1, SFREQ=1,
  errcpue=~0, effcpue=~0, srresiduals=~0, errimp=~0, 
  verbose=FALSE) {

  # Initial smoother value is 0
  cpue_smooth <- NULL

  # Selectivity
  sel <- sel(omp)

  # PB
  if(verbose)
    pb <- utils::txtProgressBar(min = years[1], max = years[length(years)],
      initial = 1, style=3, title="Years:")

  for (y in years[seq.int(1L, length(years), SFREQ)]) {

    # Get catch data, no error
    tc <- catch(omp)[,ac(y - DLAG)]

    # Get CPUE
    # TODO USE real cpue for historic period
    cpue <- vb(x=window(omp, end=y - DLAG), sel=window(sel, end= y - DLAG)) / 1000

    # CPUE ERROR
    cpue <- cpue + eval(errcpue[[2]])

    # CPUE EFFICIENCY BIAS
    cpue <- cpue + eval(effcpue[[2]])
    
    # Get smoothed CPUE using last available timestep
    if (is.null(cpue_smooth)){
      cpue_smooth <- cpue[,ac(y - DLAG)]
    } else {
      cpue_smooth <- responsiveness * cpue[,ac(y - DLAG)] +
        (1 - responsiveness) * cpue_smooth
    }

    # Calc recommended catch scalar
    rate <- cpue_smooth
    rate[] <- (cpue_smooth - biomass_limit) * hr_multiplier /
      (biomass_threshold - biomass_limit)
    rate[cpue_smooth < biomass_limit] <- 0
    rate[cpue_smooth > biomass_threshold] <- hr_multiplier[cpue_smooth > biomass_threshold]

    # Set catch for next SFREQ years, starting in y + MLAG
    tac <- FLCore::expand(tc, year=seq(y + MLAG, y + MLAG + SFREQ - 1))
    tac[] <- rep(pmin(c(cpue_smooth * rate), c(maxTAC)), each=SFREQ)

    # Implementation error
    nc <- tac + eval(errimp[[2]])

    # Parse srresiduals
    if(is(srresiduals, "formula")) {
      sr.residuals <- eval(srresiduals[[2]]) +
        FLQuant(0, dimnames=c(dimnames(nc)[-2],
        list(year=seq(y + MLAG, y + MLAG + SFREQ - 1))))
    }
    else {
      sr.residuals <- srresiduals[, ac(seq(y + MLAG, y + MLAG + SFREQ - 1))]
    }

    # Project om
    omp <- fwd(omp, as.fwdControl(catch=nc),
      sr=sr, sr.residuals=sr.residuals, sr.residuals.mult=TRUE)

    # PRINT
    if(verbose)
      setTxtProgressBar(pb, y)
  }
  return(window(omp, end=y))
} # }}}
