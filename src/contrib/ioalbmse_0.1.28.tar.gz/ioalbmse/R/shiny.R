# shiny.R - DESC
# ioalbmse/R/shiny.R

# Copyright European Union, 2015-2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

# runapp {{{
runapp <- function() {

	# LOAD data
	# data(om)

	#
	appDir <- system.file("shiny-apps", "mseapp", package="ioalbmse")

	if(appDir =="") {
		stop("Could not find shiny app directory. Try re-installing the package")
	}

	shiny::runApp(appDir, display.mode="normal")
} # }}}
