# ui.R - DESC
# ui.R

# Copyright 2015 EC JRC
# Iago Mosqueira & Dimitrios Damalas. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:


# LABELS
lab <- lapply(sce[,1:7], unique)

#
fluidPage(
  titlePanel("IOTC Albacore MSE"),
  
  sidebarLayout(
    sidebarPanel(
      helpText("Operating Model variables."),
      
			# M
      selectInput("Minp", 
        label = "Natural Mortality (M)",
        choices = c("Select one or more" = "", lab$M),
        selected = lab$M,
				multiple = TRUE
			),
			# sigmaR
      selectInput("sigmaRinp", 
        label = "Recruitment variance (sigmaR)",
        choices = c("Select one or more" = "", lab$sigmaR),
        selected = lab$sigmaR,
				multiple = TRUE
			),
			# steepness
      selectInput("steepnessinp", 
        label = "SR steepness",
        choices = c("Select one or more" = "", lab$steepness),
        selected = lab$steepness,
				multiple = TRUE
			),
			# cpuecv
      selectInput("cpuecvinp", 
        label = "CPUE CV",
        choices = c("Select one or more" = "", lab$cpuecv),
        selected = lab$cpuecv,
				multiple = TRUE
			),
			# ESS
      selectInput("essinp", 
        label = "Weight of length data (ESS)",
        choices = c("Select one or more" = "", lab$ess),
        selected = lab$ess,
				multiple = TRUE
			),
			# llq
      selectInput("llqinp", 
        label = "Longline catchability trend (LL Q)",
        choices = c("Select one or more" = "", lab$llq),
        selected = lab$llq,
				multiple = TRUE
			),
			# llsel
      selectInput("llselinp", 
        label = "Longline selectivity function (LL sel)",
        choices = c("Select one or more" = "", lab$llsel),
        selected = lab$llsel,
				multiple = TRUE
			)
  ),
  mainPanel(
 		tabsetPanel(
      tabPanel("OM",
				fluidRow(
					column(width=12, align="center",
						plotOutput("plotTS")
					)
				),
				fluidRow(
					column(width=4, align="center",
						plotOutput("plotA")
					),
					column(width=4, align="center",
						plotOutput("plotB")
					),
					column(width=4, align="center",
						plotOutput("plotC")
					)
				)
			), 
      tabPanel("Summary", verbatimTextOutput("summary")), 
      tabPanel("Table", tableOutput("table"))
    )
	)
 )
)

