# robust.R - DESC
# /robust.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

library(doParallel)
registerDoParallel(detectCores()-2)

# Setup
data(om)
data(indicators)

years <- seq(2015, length=21)
omp <- slimFLStock(fwdWindow(om, end=tail(years, 1) + 9, br))

# --- BRULE

# E0
RbE0 <- BRule(om=omp, sr=sro, years=years,
  bthreshold=0.95, blim=0.4, ftarget=refpts['FMSY'], bmsy=refpts['SBMSY',],
  SFREQ=2, DLAG=2, MLAG=2,
  errcpue=~rnorm(mean=0, sd=cpue * 0.20), effcpue=~0,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)))

# effcpue
Rbec10 <- BRule(om=omp, sr=sro, years=years,
  bthreshold=0.95, blim=0.4, ftarget=refpts['FMSY'], bmsy=refpts['SBMSY',],
  SFREQ=2, DLAG=2, MLAG=2,
  errcpue=~rnorm(mean=0, sd=cpue * 0.10), effcpue=~0.10,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)))

Rbec40 <- BRule(om=omp, sr=sro, years=years,
  bthreshold=0.95, blim=0.4, ftarget=refpts['FMSY'], bmsy=refpts['SBMSY',],
  SFREQ=2, DLAG=2, MLAG=2,
  errcpue=~rnorm(mean=0, sd=cpue * 0.40), effcpue=~0.40,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)))

Rbec60 <- BRule(om=omp, sr=sro, years=years,
  bthreshold=0.95, blim=0.4, ftarget=refpts['FMSY'], bmsy=refpts['SBMSY',],
  SFREQ=2, DLAG=2, MLAG=2,
  errcpue=~rnorm(mean=0, sd=cpue * 0.60), effcpue=~0.60,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)))

robRB <- FLStocks(RbE0=RbE0, Rbec10=Rbec10, Rbec40=Rbec40, Rbec60=Rbec60)

plot(robRB)


# -- IRATE

Ie0 <- IRate(omp=omp, sr=sro, year=years, yref=seq(1981, 2010), 
  responsiveness=0.9, hr_multiplier=1.1, biomass_threshold=0.5,
  biomass_limit=0.2, maxTAC=400000,
  errcpue=~0, effcpue=~0,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.2, b=0.1)),
  DLAG=2, MLAG=2, SFREQ=2)

# effcpue
Ief20 <- IRate(omp=omp, sr=sro, year=years, yref=seq(1981, 2010), 
  responsiveness=0.9, hr_multiplier=1.1, biomass_threshold=0.5,
  biomass_limit=0.2, maxTAC=400000,
  errcpue=~0, effcpue=~0.20,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.2, b=0.1)),
  DLAG=2, MLAG=2, SFREQ=2)

Ief10 <- IRate(omp=omp, sr=sro, year=years, yref=seq(1981, 2010), 
  responsiveness=0.9, hr_multiplier=1.1, biomass_threshold=0.5,
  biomass_limit=0.2, maxTAC=400000,
  errcpue=~0, effcpue=~0.10,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.2, b=0.1)),
  DLAG=2, MLAG=2, SFREQ=2)

Ief05 <- IRate(omp=omp, sr=sro, year=years, yref=seq(1981, 2010), 
  responsiveness=0.9, hr_multiplier=1.1, biomass_threshold=0.5,
  biomass_limit=0.2, maxTAC=400000,
  errcpue=~0, effcpue=~0.05,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.2, b=0.1)),
  DLAG=2, MLAG=2, SFREQ=2)

Ief01 <- IRate(omp=omp, sr=sro, year=years, yref=seq(1981, 2010), 
  responsiveness=0.9, hr_multiplier=1.1, biomass_threshold=0.5,
  biomass_limit=0.2, maxTAC=400000,
  errcpue=~0, effcpue=~0.01,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.2, b=0.1)),
  DLAG=2, MLAG=2, SFREQ=2)

robIR <- FLStocks(Ie0=Ie0, Ief20=Ief20, Ief10=Ief10, Ief05=Ief05, Ief01=Ief01)

plot(robIR)

plotOMR(om, robIR, refpts=refpts["SBMSY"])

save(robRB, robIR, file="../data/robust.RData")

