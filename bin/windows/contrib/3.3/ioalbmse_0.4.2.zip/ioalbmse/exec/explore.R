# explore.R - DESC
# /explore.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

library(doParallel)
registerDoParallel(detectCores()-1)

# Setup
data(om)
data(indicators)

years <- seq(2015, length=21)
omp <- fwdWindow(om, end=tail(years, 1) + 9, br)

# -- CONSTANT CATCH
cc <- FLCore::expand(catch(om)[,'2012'], year=seq(2013, 2044))

Rcc <- fwd(omp, asfwdControl(catch=cc), sr=sro)

# -- CONSTANT F
cf <- FLCore::expand(fbar(om)[,'2012'], year=seq(2013, 2044))

Rcf <- fwd(omp, asfwdControl(f=cf), sr=sro)

save(Rcc, Rcf, file="../data/cruns.RData", compress="xz", compression_level=9)

# -- IRATE

# GRID
igrid <- list(
  # PARAMS
  responsiveness=seq(0.4, 0.8, length=6),
  hr_multiplier=seq(0.5, 1.5, length=6),
  biomass_threshold=seq(0.2, 0.4, length=3),
  biomass_limit=seq(0.3, 0.5, length=3),
  maxTAC=seq(3e5, 5e5, length=3),
  # TIMING
  SFREQ=seq(1,3),
  DLAG=seq(1,2))

igrid <- list(
  # PARAMS
  responsiveness=c(0.3, 0.9),
  hr_multiplier=c(0.4, 0.8),
  biomass_threshold=c(0.2, 0.4),
  biomass_limit=c(0.4, 0.6),
  maxTAC=c(3e5, 4e5),
  # TIMING
  SFREQ=c(2),
  DLAG=c(2))

prod(unlist(lapply(igrid, length)))

# RUN
iruns <- doRuns(IRate, om=omp, sr=sro, years=years, grid=igrid,
  yref=1995:2010, errcpue=~rnorm(mean=0, sd=cpue * 0.20),
  effcpue=~0, srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)), MLAG=2)

# PERFORMANCE
iperf <- rbindlist(parallel::mclapply(iruns, performance, indicators, refpts,
  mc.cores=detectCores()-1), idcol='run')
iperf[, "mp" := "irate"]
setcolorder(iperf, c(length(iperf), 1:(length(iperf)-1)))

iperq <- iperf[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9), na.rm=TRUE)),
  keyby=list(mp, indicator, name, year, run)]

save(iruns, iperf, iperq, file="../data/iruns.RData", compress="xz", compression_level=9)

# -- BRULE

# GRID
bgrid <- list(
  # PARAMS
  bthreshold=seq(0.8, 1.2, length=3),
  blim=seq(0.3, 0.6, length=2), 
  # TIMING
  SFREQ=seq(1, 3),
  DLAG=seq(1, 2))

prod(unlist(lapply(bgrid, length)))

# RUN
bruns <- doRuns(BRule, om=omp, sr=sro, years=years, grid=bgrid,
  ftarget=refpts['FMSY'], bmsy=refpts['SBMSY',],
  MLAG=2, errcpue=~rnorm(mean=0, sd=cpue * 0.20),
  effcpue=~0, srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.3, b=0.2)))

bperf <- rbindlist(mclapply(bruns, performance, indicators, refpts,
  mc.cores=detectCores()-2), idcol='run')
bperf[, "mp" := "brule"]

bperq <- bperf[, as.list(quantile(data, probs=c(0.1, 0.25, 0.50, 0.75, 0.9))),
  keyby=list(mp, indicator, name, year, run)]

save(bruns, bperf, bperq, file="../data/bruns.RData", compress="xz", compression_level=9)

