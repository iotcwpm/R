# perturbation.R - DESC
# /perturbation.R

# Copyright European Union, 2016
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.

library(ioalbmse)

library(doParallel)
registerDoParallel(detectCores()-1)

# SETUP
data(om)
data(indicators)

years <- seq(2015, length=100)
omp <- fwdWindow(om, end=tail(years, 1) + 9, br)

# 90 years at FMSY
fmsy <- FLQuant(res$Fstd_MSY, dimnames=list(year=2017:2067, iter=seq(dims(om)$iter)))
Rper <- fwd(omp, asfwdControl(f=fmsy), sr=sro)

# 1 year high F
sfmsy <- FLQuant(res$Fstd_MSY*4, dimnames=list(year=2068, iter=seq(dims(om)$iter)))
Rper <- fwd(Rper, asfwdControl(f=sfmsy), sr=sro)

# -- PERTURB IRate

RpIR <- IRate(Rper, sro, 2069:2112, yref=seq(2020, 2050),
  responsiveness=0.9, hr_multiplier=1.1, biomass_threshold=0.5,
  biomass_limit=0.2, maxTAC=600000, DLAG=1, MLAG=1, SFREQ=2,
  errcpue=~0, effcpue=~0,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.2, b=0.1)))

# -- PERTURB BRule
RpBR <- BRule(Rper, sro, 2069:2112, bthreshold=1,
  blim=0.4*refpts['SBMSY'], ftarget=refpts['FMSY'], bmsy=refpts['SBMSY'],
  DLAG=1, MLAG=1, SFREQ=1, errcpue=~0, effcpue=~0, errimp=~0,
  srresiduals=exp(FLife::noise(1, FLQuant(0, dimnames=list(year=seq(years[1],
    tail(years, 1) + 6))), sd=0.2, b=0.1)))

Rper <- window(Rper, end=2068)

save(Rper, RpIR, RpBR, file="../data/perturb.RData", compress='xz')
